<?php
  echo exec("/bin/ping -c 4 ".$_GET["address"]);

?>
