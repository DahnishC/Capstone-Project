timeout 120 ./flag-reader
